import react, { useState } from "react";
function Min() {
  let currentDate = new Date();
  let now = currentDate.getMinutes();
  const [time, setValue] = useState(now);
  function Increase() {
    let currentDate = new Date();
    let latest = currentDate.getMinutes();
    setValue(latest);
  }
  return (
    <div>
      <p>Click this button to get current minute.</p>
      <h1>{time} </h1>
      <button onClick={Increase}>+</button>
    </div>
  );
}
export default Min;
