import react from "react";
import reactDom from "react-dom";
import Min from "./Min";
reactDom.render(
  <div>
    <Min></Min>
  </div>,
  document.getElementById("root")
);
