import react, { useState } from "react";
function Form() {
  const [name, changeName] = useState("");
  const [setheading, changeValue] = useState("");
  function changeOccur(event) {
    // console.log(event.target.value);
    changeName(event.target.value);
  }
  function clicked(event) {
    changeValue(name);
    event.preventDefault(); //form won't be refresh
  }

  return (
    <div className="container">
      <form>
        <h1> Hello {setheading} </h1>
        <input
          onChange={changeOccur}
          type="text"
          placeholder="what's your name"
        ></input>
        <button onClick={clicked}> Submit </button>
      </form>
    </div>
  );
}
export default Form;
