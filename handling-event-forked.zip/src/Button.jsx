import react, { useState } from "react";
function App() {
  const [state, changeState] = useState("Hello");
  const [isMouseover, setmouseOver] = useState(false);
  function handleMouseover() {
    setmouseOver(true);
  }
  function handleMouseout() {
    setmouseOver(false);
  }
  function Click() {
    changeState("Submitted");
  }
  return (
    <div className="container">
      <h1>{state}</h1>
      <input type="text" placeholder="What's your name?"></input>
      <button
        style={{ backgroundColor: isMouseover ? "black" : "white" }}
        onClick={Click}
        onMouseOver={handleMouseover}
        onMouseOut={handleMouseout}
      >
        Submit
      </button>
    </div>
  );
}
export default App;
