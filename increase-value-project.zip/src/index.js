import react from "react";
import reactDome from "react-dom";
import App from "./App";
reactDome.render(
  <div>
    <App></App>
  </div>,
  document.getElementById("root")
);
