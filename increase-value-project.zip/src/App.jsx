import react, { useState } from "react";
function App() {
  const [Is, setValue] = useState(0);
  //Is is initial state
  function Increase() {
    setValue(Is + 1);
  }
  return (
    <div >
      <h1>{Is}</h1>
      <button onClick={Increase}>+</button>
    </div>
  );
}
export default App;
